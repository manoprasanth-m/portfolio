#### Portfolio in Neumorphism UI/UX Design built with ReactJs.

Portfolio/Resume Website using ReactJS.

## Steps to contribute:

1. Clone or Download the project

2. Open the project in VS Code or any other code editor

3. Open Terminal

4. Type the below commands

```shell
$ cd Portfolio-Neumorphism-ReactJS
$ npm install
$ npm start
```

That's all !
